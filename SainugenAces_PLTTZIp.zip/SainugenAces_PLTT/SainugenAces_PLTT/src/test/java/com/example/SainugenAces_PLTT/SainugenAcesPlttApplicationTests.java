package com.example.SainugenAces_PLTT;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SainugenAcesPlttApplicationTests {

	@Test
	void contextLoads() {
	}

}
