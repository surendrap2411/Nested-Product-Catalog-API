package com.example.SainugenAces_PLTT.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SainugenAces_PLTT.Entity.Rating;

public interface RatingRepository extends JpaRepository<Rating,Integer>{

}
