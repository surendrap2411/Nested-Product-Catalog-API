package com.example.SainugenAces_PLTT.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.SainugenAces_PLTT.Entity.Product;

public interface ProductRepository extends JpaRepository<Product,Integer>{

}
