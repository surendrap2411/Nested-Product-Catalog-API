package com.example.SainugenAces_PLTT;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SainugenAcesPlttApplication {

	public static void main(String[] args) {
		SpringApplication.run(SainugenAcesPlttApplication.class, args);
	}

}
